#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
show() {
  local name="$1" port="$2" desc="$3" pids
  pids="$(port_pids "$port" | tr '\n' ' ')"
  if [[ -n "$pids" ]]; then
    printf '%-12s %-6s LISTENING  PID(s): %-16s %s\n' "$name" "$port" "$pids" "$desc"
    lsof -nP -iTCP:"$port" -sTCP:LISTEN 2>/dev/null | tail -n +2 || true
  else
    printf '%-12s %-6s NOT LISTENING  %s\n' "$name" "$port" "$desc"
  fi
}
show 'PostgreSQL' "$PG_PORT" 'Database (may be shared with other projects)'
show 'Backend' "$BACKEND_PORT" "http://localhost:$BACKEND_PORT"
show 'Storefront' "$STOREFRONT_PORT" "http://localhost:$STOREFRONT_PORT"
show 'PHP/other' 9000 'Existing Magento/PHP-FPM/PhpStorm services; do not stop'
printf '\nManaged launcher PIDs:\n'
for name in backend storefront; do
  if tracked_running "$name"; then echo "$name: $(cat "$STATE_DIR/$name.pid") running"; else echo "$name: not tracked/running"; fi
done
printf '\nPostgreSQL login (if your local role is medusa):\n  psql -h localhost -p %s -U medusa -d medusa-medusa-learning\n' "$PG_PORT"
printf '\nLogs:\n  tail -n 60 "%s/backend.log"\n  tail -n 60 "%s/storefront.log"\n' "$STATE_DIR" "$STATE_DIR"
